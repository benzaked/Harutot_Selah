export const firebaseConfig = {
    apiKey: "AIzaSyCKkz8RoygajS_2QoffdwjMocNtPIAzGpI",
    authDomain: "finalprojectrn.firebaseapp.com",
    databaseURL: "https://finalprojectrn.firebaseio.com",
    projectId: "finalprojectrn",
    storageBucket: "finalprojectrn.appspot.com",
    messagingSenderId: "1003696475172",
    appId: "1:1003696475172:web:9011bfc21b2cf5a67c5cb1",
    measurementId: "G-8RLX522SSZ"
  };