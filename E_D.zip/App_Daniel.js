import React , {useState} from 'react';
import { StyleSheet, Text, View,TextInput,Button,} from 'react-native';
import {createAppContainer,createSwitchNavigator} from 'react-navigation'
import LoginScreen from './screens/LoginScreen'
import loadingScreen from './screens/LoadingScreen'
import DashboardScreen from './screens/DashboardScreen'
import * as firebase from 'firebase'
import {firebaseConfig} from './config'


export default function App() {
  
  return (
  <AppNavigator />
  );
}
const appSwitchNavigator = createSwitchNavigator({
  
  LoginScreen:LoginScreen,
  loadingScreen:loadingScreen,
  DashboardScreen:DashboardScreen
})
const AppNavigator = createAppContainer(appSwitchNavigator)

const styles = StyleSheet.create({
  screen: {
    padding: 50

  },
  inputContainer: {
    width: "80%",
    borderBottomColor: 'black',
    borderBottomWidth: 1, 
    padding:10 
  }
});
  
 
